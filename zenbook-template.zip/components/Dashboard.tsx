
import React, { useMemo } from 'react';
import { storageService } from '../services/storageService';
import { SERVICES } from '../constants';
import { 
  TrendingUp, 
  Calendar, 
  BarChart3, 
  PhoneCall, 
  Euro, 
  ArrowUpRight, 
  Users,
  Clock
} from 'lucide-react';
import { isToday, isThisMonth, startOfDay } from 'date-fns';

const Dashboard: React.FC = () => {
  const appointments = storageService.getAppointments();
  const customers = storageService.getCustomers();

  const stats = useMemo(() => {
    let revenueToday = 0;
    let revenueMonth = 0;
    let revenueTotal = 0;

    appointments.forEach(app => {
      const service = SERVICES.find(s => s.id === app.serviceId);
      const price = service?.price || 0;

      if (isToday(app.startTime)) revenueToday += price;
      if (isThisMonth(app.startTime)) revenueMonth += price;
      revenueTotal += price;
    });

    return {
      revenueToday,
      revenueMonth,
      revenueTotal,
      activeCustomers: customers.length,
      appointmentsCount: appointments.length,
      callsToday: Math.floor(Math.random() * 15) + 5 // Simulierter Wert
    };
  }, [appointments, customers]);

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col gap-2">
        <h3 className="text-4xl font-black text-slate-900 tracking-tight">Dashboard Overview</h3>
        <p className="text-slate-500 font-medium">Alle wichtigen Kennzahlen Ihres Salons auf einen Blick.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {[
          { label: 'Umsatz Heute', value: `${stats.revenueToday} €`, icon: <Calendar className="w-6 h-6" />, color: 'bg-indigo-600', trend: '+12%' },
          { label: 'Umsatz Monat', value: `${stats.revenueMonth} €`, icon: <BarChart3 className="w-6 h-6" />, color: 'bg-emerald-600', trend: '+8%' },
          { label: 'Umsatz Gesamt', value: `${stats.revenueTotal} €`, icon: <Euro className="w-6 h-6" />, color: 'bg-amber-500', trend: '+24%' },
          { label: 'Anrufe Heute', value: stats.callsToday, icon: <PhoneCall className="w-6 h-6" />, color: 'bg-rose-500', trend: 'Live' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/50 group hover:scale-[1.02] transition-all">
            <div className="flex justify-between items-start mb-6">
              <div className={`w-14 h-14 ${stat.color} rounded-2xl flex items-center justify-center text-white shadow-lg`}>
                {stat.icon}
              </div>
              <span className="text-[10px] font-black px-3 py-1 bg-slate-50 text-slate-400 rounded-full border border-slate-100 uppercase tracking-widest group-hover:bg-white transition-colors">
                {stat.trend}
              </span>
            </div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <h4 className="text-3xl font-black text-slate-900">{stat.value}</h4>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Detail Insights */}
        <div className="lg:col-span-2 bg-white rounded-[3rem] p-10 shadow-xl border border-slate-50">
           <div className="flex items-center justify-between mb-10">
              <h4 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                <TrendingUp className="w-6 h-6 text-indigo-600" /> Performance Analyse
              </h4>
           </div>
           
           <div className="space-y-6">
              {[
                { label: 'Kundenbindung', val: 84, color: 'bg-indigo-600' },
                { label: 'Auslastung Team', val: 72, color: 'bg-emerald-500' },
                { label: 'Produkt-Umsatz Anteil', val: 18, color: 'bg-amber-400' }
              ].map((item, i) => (
                <div key={i} className="space-y-3">
                  <div className="flex justify-between text-xs font-black uppercase tracking-widest text-slate-500">
                    <span>{item.label}</span>
                    <span>{item.val}%</span>
                  </div>
                  <div className="h-4 bg-slate-50 rounded-full overflow-hidden border border-slate-100">
                    <div className={`h-full ${item.color} transition-all duration-1000`} style={{ width: `${item.val}%` }}></div>
                  </div>
                </div>
              ))}
           </div>
        </div>

        {/* Quick Actions / Activity */}
        <div className="bg-[#001e3c] rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <h4 className="text-xl font-black mb-8 relative z-10">System Status</h4>
          
          <div className="space-y-6 relative z-10">
             <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                <Users className="w-5 h-5 text-indigo-400" />
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kunden Gesamt</p>
                   <p className="text-lg font-black">{stats.activeCustomers}</p>
                </div>
             </div>
             <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                <Clock className="w-5 h-5 text-emerald-400" />
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Termine Database</p>
                   <p className="text-lg font-black">{stats.appointmentsCount}</p>
                </div>
             </div>
          </div>
          
          <button className="w-full mt-10 py-4 bg-white text-[#001e3c] rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-50 transition-all flex items-center justify-center gap-2">
             Bericht exportieren <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
