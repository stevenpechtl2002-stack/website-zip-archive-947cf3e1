
import React, { useRef } from 'react';
import { storageService, Customer } from '../services/storageService';
import { Search, User, Mail, Phone, Calendar, MoreVertical, Star, TrendingUp, Download, Upload, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { de } from 'date-fns/locale';

interface Props {
  isDarkMode: boolean;
}

const CustomerManagement: React.FC<Props> = ({ isDarkMode }) => {
  const [customers, setCustomers] = React.useState<Customer[]>(storageService.getCustomers());
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshCustomers = () => {
    setCustomers(storageService.getCustomers());
  };

  const handleExportCSV = () => {
    if (customers.length === 0) return;

    const headers = ['ID', 'Name', 'Email', 'Telefon', 'Besuche', 'Umsatz', 'Letzter Besuch'];
    const csvContent = [
      headers.join(','),
      ...customers.map(c => [
        c.id,
        `"${c.name}"`,
        c.email,
        `"${c.phone}"`,
        c.bookingsCount,
        c.totalSpent,
        c.lastVisit || ''
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `zenbook_kunden_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n');
      const newCustomers: Customer[] = [...customers];

      // Simple CSV parser (skipping header)
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        const parts = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/); // Split by comma but respect quotes
        if (parts.length < 4) continue;

        const name = parts[1]?.replace(/"/g, '') || 'Unbekannt';
        const email = parts[2] || 'no-email@zenbook.de';
        const phone = parts[3]?.replace(/"/g, '') || 'Keine Nummer';

        // Check if customer already exists by email
        if (!newCustomers.find(c => c.email === email)) {
          newCustomers.push({
            id: Math.random().toString(36).substr(2, 9),
            name,
            email,
            phone,
            totalSpent: 0,
            bookingsCount: 0,
            lastVisit: undefined
          });
        }
      }

      localStorage.setItem('zenbook_db_customers', JSON.stringify(newCustomers));
      refreshCustomers();
      alert('Kunden erfolgreich importiert!');
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-500">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h3 className={`text-4xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Kundenstamm</h3>
          <p className="text-slate-500 font-medium mt-2">Verwalte deine loyale Community und analysiere das Buchungsverhalten.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-4">
          <input 
            type="file" 
            accept=".csv" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={handleImportCSV} 
          />
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className={`flex items-center gap-3 px-6 py-4 border rounded-2xl font-black text-xs transition-all shadow-sm active:scale-95 ${isDarkMode ? 'bg-white/5 border-white/10 text-white hover:bg-white/10' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
          >
            <Upload className="w-4 h-4" /> Import (CSV)
          </button>
          
          <button 
            onClick={handleExportCSV}
            className={`flex items-center gap-3 px-6 py-4 border rounded-2xl font-black text-xs transition-all shadow-sm active:scale-95 ${isDarkMode ? 'bg-white/5 border-white/10 text-white hover:bg-white/10' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
          >
            <Download className="w-4 h-4" /> Export (CSV)
          </button>

          <div className={`px-6 py-4 rounded-[1.8rem] border flex items-center gap-3 ${isDarkMode ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-emerald-50 border-emerald-100'}`}>
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            <div>
              <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest leading-none">Wachstum</p>
              <p className={`text-lg font-black ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>+14%</p>
            </div>
          </div>
        </div>
      </div>

      <div className={`rounded-[3.5rem] shadow-2xl border overflow-hidden ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-white'}`}>
        <div className={`p-8 border-b flex items-center gap-4 ${isDarkMode ? 'border-white/5' : 'border-slate-50'}`}>
          <div className="relative flex-1">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input 
              type="text" 
              placeholder="Kunden suchen..." 
              className={`w-full pl-16 pr-8 py-4 border-none font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all ${isDarkMode ? 'bg-white/5 text-white placeholder:text-slate-600' : 'bg-slate-50 text-slate-600'}`}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`${isDarkMode ? 'bg-white/5' : 'bg-slate-50/50'}`}>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Kunde</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Kontakt</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Besuche</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Umsatz</th>
                <th className="px-8 py-6 text-[10px] font-black text-slate-500 uppercase tracking-widest">Letzter Besuch</th>
                <th className="px-8 py-6"></th>
              </tr>
            </thead>
            <tbody className={`divide-y ${isDarkMode ? 'divide-white/5' : 'divide-slate-50'}`}>
              {customers.map(customer => (
                <tr key={customer.id} className={`group transition-colors ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-slate-50/50'}`}>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black ${isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-indigo-50 text-indigo-600'}`}>
                        {customer.name.charAt(0)}
                      </div>
                      <div>
                        <p className={`font-black ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{customer.name}</p>
                        <p className="text-[10px] font-bold text-slate-500">ID: {customer.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="space-y-1">
                      <div className={`flex items-center gap-2 text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                        <Mail className="w-3.5 h-3.5 text-slate-500" /> {customer.email}
                      </div>
                      <div className={`flex items-center gap-2 text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                        <Phone className="w-3.5 h-3.5 text-slate-500" /> {customer.phone}
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-center">
                    <span className={`px-4 py-2 rounded-xl text-xs font-black ${isDarkMode ? 'bg-white/5 text-slate-400' : 'bg-slate-100 text-slate-600'}`}>
                      {customer.bookingsCount}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <span className={`text-sm font-black ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{customer.totalSpent.toFixed(2)} €</span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                      <Calendar className="w-3.5 h-3.5" /> 
                      {customer.lastVisit ? format(new Date(customer.lastVisit), 'dd. MMM yyyy', { locale: de }) : 'Nie'}
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <button className="p-2 text-slate-500 hover:text-blue-500 transition-colors">
                      <MoreVertical className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomerManagement;
