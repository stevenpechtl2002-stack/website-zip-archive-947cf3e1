
import React, { useState, useEffect } from 'react';
import { Package, Plus, Search, Trash2, Tag, DollarSign, Image as ImageIcon, X } from 'lucide-react';
import { Product } from '../types';

interface Props {
  isDarkMode: boolean;
}

const ProductManagement: React.FC<Props> = ({ isDarkMode }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    brand: '',
    price: 0,
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=400'
  });

  useEffect(() => {
    const saved = localStorage.getItem('zenbook_db_products');
    if (saved) setProducts(JSON.parse(saved));
    else {
      const initial = [
        { id: 'p1', name: 'Premium Argan Oil', brand: 'ZenCare', price: 29.99, image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&q=80&w=400' },
        { id: 'p2', name: 'Nail Repair Serum', brand: 'Kawaii Nails', price: 15.50, image: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&q=80&w=400' }
      ];
      setProducts(initial);
      localStorage.setItem('zenbook_db_products', JSON.stringify(initial));
    }
  }, []);

  const handleAdd = () => {
    if (!newProduct.name || !newProduct.brand) return;
    const prod: Product = {
      ...newProduct,
      id: Math.random().toString(36).substr(2, 9)
    };
    const updated = [...products, prod];
    setProducts(updated);
    localStorage.setItem('zenbook_db_products', JSON.stringify(updated));
    setShowModal(false);
    setNewProduct({ name: '', brand: '', price: 0, image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=400' });
  };

  const removeProduct = (id: string) => {
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    localStorage.setItem('zenbook_db_products', JSON.stringify(updated));
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-500">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h3 className={`text-4xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Produkt Katalog</h3>
          <p className="text-slate-500 font-medium mt-2">Verwalten Sie Ihr Sortiment für den Direktverkauf im Salon.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className={`flex items-center gap-3 px-8 py-5 rounded-[2rem] font-black text-xs uppercase tracking-widest transition-all shadow-xl active:scale-95 ${isDarkMode ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-[#001e3c] text-white hover:bg-indigo-600'}`}
        >
          <Plus className="w-5 h-5 stroke-[3px]" /> Produkt hinzufügen
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
        {products.map(product => (
          <div key={product.id} className={`rounded-[2.5rem] overflow-hidden border shadow-xl group hover:shadow-2xl transition-all ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-slate-50'}`}>
            <div className="h-48 relative">
              <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={product.name} />
              <button 
                onClick={() => removeProduct(product.id)}
                className={`absolute top-4 right-4 p-3 backdrop-blur-md rounded-xl text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg ${isDarkMode ? 'bg-black/60' : 'bg-white/90'}`}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <div className="p-8">
              <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">{product.brand}</span>
              <h4 className={`text-lg font-black mt-1 mb-4 truncate ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{product.name}</h4>
              <div className={`flex items-center justify-between pt-4 border-t ${isDarkMode ? 'border-white/5' : 'border-slate-50'}`}>
                 <div className={`flex items-center gap-1.5 font-black ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                   <Tag className="w-4 h-4 text-slate-500" />
                   {product.price.toFixed(2)} €
                 </div>
                 <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest">In Stock</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className={`rounded-[3rem] w-full max-w-lg p-12 shadow-2xl ${isDarkMode ? 'bg-black border border-white/10' : 'bg-white'}`}>
            <div className="flex justify-between items-center mb-10">
              <h4 className={`text-2xl font-black uppercase ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Neues Produkt</h4>
              <button onClick={() => setShowModal(false)} className="p-2 text-slate-500 hover:text-rose-500"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Produkt Name</label>
                <input type="text" className={`w-full px-6 py-4 rounded-2xl outline-none font-bold ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50'}`} 
                  value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Marke</label>
                  <input type="text" className={`w-full px-6 py-4 rounded-2xl outline-none font-bold ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50'}`} 
                    value={newProduct.brand} onChange={e => setNewProduct({...newProduct, brand: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Preis (€)</label>
                  <input type="number" className={`w-full px-6 py-4 rounded-2xl outline-none font-bold ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50'}`} 
                    value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: parseFloat(e.target.value)})} />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Bild URL</label>
                <input type="text" className={`w-full px-6 py-4 rounded-2xl outline-none font-bold ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50'}`} 
                  value={newProduct.image} onChange={e => setNewProduct({...newProduct, image: e.target.value})} />
              </div>
              <button onClick={handleAdd} className={`w-full py-5 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl transition-colors ${isDarkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-[#001e3c] hover:bg-indigo-600'}`}>Speichern</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductManagement;
