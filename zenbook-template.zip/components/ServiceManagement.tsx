
import React from 'react';
import { Service } from '../types';
import { Search, Plus, MoreVertical, Clock, Tag } from 'lucide-react';

interface Props {
  services: Service[];
  // Added isDarkMode to props
  isDarkMode: boolean;
}

const ServiceManagement: React.FC<Props> = ({ services, isDarkMode }) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
          <input 
            type="text" 
            placeholder="Nach Dienstleistungen suchen..." 
            className={`w-full pl-12 pr-4 py-3 border rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none shadow-sm transition-colors ${isDarkMode ? 'bg-white/5 border-white/10 text-white placeholder:text-slate-600' : 'bg-white border-slate-200 text-slate-900'}`}
          />
        </div>
        <button className={`flex items-center gap-2 px-6 py-3 text-white rounded-2xl font-semibold transition-all shadow-lg active:scale-95 ${isDarkMode ? 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20' : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100'}`}>
          <Plus className="w-5 h-5" />
          Service hinzufügen
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map(service => (
          <div key={service.id} className={`p-6 rounded-3xl border shadow-sm hover:shadow-md transition-all group relative ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-slate-200'}`}>
            <button className="absolute top-4 right-4 p-2 text-slate-500 hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreVertical className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-indigo-50 text-indigo-600'}`}>
                <Tag className="w-6 h-6" />
              </div>
              <div>
                <span className={`text-xs font-bold uppercase tracking-widest ${isDarkMode ? 'text-blue-400' : 'text-indigo-600'}`}>{service.category}</span>
                <h4 className={`font-bold text-lg leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{service.name}</h4>
              </div>
            </div>
            
            <div className={`flex items-center gap-6 mt-6 pt-6 border-t ${isDarkMode ? 'border-white/5' : 'border-slate-50'}`}>
              <div className="flex items-center gap-2 text-slate-500">
                <Clock className="w-4 h-4" />
                <span className="text-sm font-medium">{service.duration} min</span>
              </div>
              <div className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                {service.price} €
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceManagement;
