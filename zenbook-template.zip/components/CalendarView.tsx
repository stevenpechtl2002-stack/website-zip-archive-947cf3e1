
import React, { useState, useEffect, useRef } from 'react';
import { 
  format, 
  isSameDay, 
  addDays,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isToday
} from 'date-fns';
import { de } from 'date-fns/locale';
import { SERVICES } from '../constants';
import { Appointment, Staff, CalendarConfig } from '../types';
import { Plus, ChevronLeft, ChevronRight, Users, X, Clock, MoreHorizontal } from 'lucide-react';

interface Props {
  appointments: Appointment[];
  selectedDate: Date;
  setSelectedDate: (date: Date) => void;
  onUpdateAppointment: (app: Appointment) => void;
  onDeleteAppointment: (id: string) => void;
  staff: Staff[];
  onSlotClick: (staffId: string, hour: number) => void;
  config: CalendarConfig;
  onConfigUpdate?: (newConfig: CalendarConfig) => void;
  isDarkMode: boolean;
}

const CalendarView: React.FC<Props> = ({ 
  appointments, 
  selectedDate, 
  setSelectedDate, 
  onUpdateAppointment,
  onDeleteAppointment,
  staff,
  onSlotClick,
  config,
  onConfigUpdate,
  isDarkMode
}) => {
  const hours = Array.from({ length: config.endHour - config.startHour }, (_, i) => i + config.startHour);
  const [viewMode, setViewMode] = useState<'day' | 'week'>('day');
  const [currentTime, setCurrentTime] = useState(new Date());
  
  const [isResizing, setIsResizing] = useState(false);
  const resizeStartX = useRef<number>(0);
  const resizeStartWidth = useRef<number>(0);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const delta = e.clientX - resizeStartX.current;
      // Erlaube nun bis zu 10px Spaltenbreite
      const newWidth = Math.max(10, Math.min(400, resizeStartWidth.current + delta));
      if (onConfigUpdate) {
        onConfigUpdate({ ...config, columnWidth: newWidth });
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.style.cursor = 'default';
      document.body.style.userSelect = 'auto';
    };

    if (isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing, config, onConfigUpdate]);

  const handleResizeStart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    resizeStartX.current = e.clientX;
    resizeStartWidth.current = config.columnWidth;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  };

  const weekDays = eachDayOfInterval({
    start: startOfWeek(selectedDate, { locale: de }),
    end: endOfWeek(selectedDate, { locale: de })
  });

  const columns = viewMode === 'day' ? staff : weekDays;
  const now = new Date();
  const currentHour = now.getHours();
  const currentMin = now.getMinutes();
  const timeIndicatorTop = (currentHour >= config.startHour && currentHour < config.endHour)
    ? ((currentHour - config.startHour) * config.rowHeight) + (currentMin / 60 * config.rowHeight)
    : -1;

  const columnWidth = config.columnWidth || 100;

  return (
    <div className={`h-full flex flex-col overflow-hidden selection:bg-blue-100 ${isDarkMode ? 'bg-[#0f172a]' : 'bg-[#f1f5f9]'}`}>
      
      {/* Navigation Bar */}
      <div className={`h-14 flex items-center justify-between px-4 border-b shrink-0 ${isDarkMode ? 'bg-slate-900 border-white/5' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="flex items-center gap-3">
          <div className={`flex items-center rounded-lg overflow-hidden border ${isDarkMode ? 'border-white/10' : 'border-slate-200'}`}>
            <button onClick={() => setSelectedDate(addDays(selectedDate, -1))} className={`p-1.5 transition-colors ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-slate-50'}`}>
              <ChevronLeft className="w-4 h-4 text-slate-500" />
            </button>
            <div className={`px-4 py-1.5 text-xs font-bold border-x ${isDarkMode ? 'border-white/10 text-white' : 'border-slate-200 text-slate-700'}`}>
              {format(selectedDate, "EEE, d. MMMM", { locale: de })}
            </div>
            <button onClick={() => setSelectedDate(addDays(selectedDate, 1))} className={`p-1.5 transition-colors ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-slate-50'}`}>
              <ChevronRight className="w-4 h-4 text-slate-500" />
            </button>
          </div>
          <button onClick={() => setSelectedDate(new Date())} className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-lg border transition-all ${isDarkMode ? 'bg-white/5 border-white/10 text-white hover:bg-white/10' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
            Heute
          </button>
        </div>

        <div className={`flex p-0.5 rounded-lg border ${isDarkMode ? 'bg-black/20 border-white/5' : 'bg-slate-100 border-slate-200'}`}>
          <button onClick={() => setViewMode('day')} className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest rounded-md transition-all ${viewMode === 'day' ? (isDarkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-900 shadow-sm') : 'text-slate-400'}`}>
            Tag
          </button>
          <button onClick={() => setViewMode('week')} className={`px-4 py-1.5 text-[9px] font-black uppercase tracking-widest rounded-md transition-all ${viewMode === 'week' ? (isDarkMode ? 'bg-slate-700 text-white' : 'bg-white text-slate-900 shadow-sm') : 'text-slate-400'}`}>
            Woche
          </button>
        </div>
      </div>

      {/* Grid View */}
      <div className="flex-1 overflow-auto custom-scrollbar relative">
        <div className="relative" style={{ minWidth: columns.length * columnWidth + 60 }}>
          
          {/* Header Row */}
          <div className={`sticky top-0 z-[60] flex border-b ml-14 ${isDarkMode ? 'bg-slate-900 border-white/10' : 'bg-white border-slate-200'}`}>
            {columns.map((item, idx) => (
              <div 
                key={idx} 
                style={{ width: `${columnWidth}px` }} 
                className={`flex-1 flex items-center justify-center p-2 border-r last:border-r-0 h-14 relative group transition-colors ${isDarkMode ? 'border-white/5 hover:bg-white/[0.02]' : 'border-slate-100 hover:bg-slate-50/50'}`}
              >
                {viewMode === 'day' ? (
                  <div className="flex items-center gap-2 px-1 max-w-full overflow-hidden">
                    {columnWidth >= 30 ? (
                      <div className={`w-7 h-7 shrink-0 rounded-full border-2 flex items-center justify-center text-[10px] font-black text-white shadow-sm border-white/20 ${(item as Staff).color.split(' ')[0]}`}>
                        {(item as Staff).name.charAt(0)}
                      </div>
                    ) : (
                      // Mikro-Indikator für extrem schmale Spalten
                      <div className={`w-1 h-6 rounded-full ${(item as Staff).color.split(' ')[0]}`} />
                    )}
                    {columnWidth > 70 && (
                      <span className={`text-[11px] font-bold truncate ${isDarkMode ? 'text-slate-200' : 'text-slate-700'}`}>
                        {(item as Staff).name}
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="text-center overflow-hidden">
                    <p className={`text-[9px] font-black uppercase tracking-wider mb-0.5 ${isSameDay(item as Date, new Date()) ? 'text-blue-600' : 'text-slate-400'}`}>
                      {format(item as Date, 'EEE', { locale: de })}
                    </p>
                    {columnWidth > 30 && (
                      <p className={`text-xs font-black ${isSameDay(item as Date, new Date()) ? 'text-blue-600' : (isDarkMode ? 'text-white' : 'text-slate-900')}`}>
                        {format(item as Date, 'd. MMM')}
                      </p>
                    )}
                  </div>
                )}
                <div onMouseDown={handleResizeStart} className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize z-50 transition-all hover:bg-blue-500/40" />
              </div>
            ))}
          </div>

          <div className="flex">
            {/* Time Gutter */}
            <div className={`sticky left-0 z-50 w-14 border-r shrink-0 ${isDarkMode ? 'bg-slate-900 border-white/10' : 'bg-white border-slate-200'}`}>
              {hours.map(hour => (
                <div key={hour} className="text-right pr-2 pt-1.5" style={{ height: `${config.rowHeight}px` }}>
                  <span className="text-[10px] font-black text-slate-400">
                    {hour.toString().padStart(2, '0')}<span className="text-[7px] align-top ml-0.5">00</span>
                  </span>
                </div>
              ))}
            </div>

            {/* Main Grid Content */}
            <div className="flex-1 flex relative">
              {timeIndicatorTop !== -1 && isToday(selectedDate) && (
                <div className="absolute left-0 right-0 h-[1.5px] bg-red-500/80 z-40 pointer-events-none" style={{ top: `${timeIndicatorTop}px` }}>
                  <div className="absolute -left-1 -top-1 w-2.5 h-2.5 rounded-full bg-red-500 border border-white" />
                </div>
              )}

              {columns.map((col, colIdx) => (
                <div 
                  key={colIdx} 
                  style={{ width: `${columnWidth}px` }} 
                  className={`flex-1 relative border-r last:border-r-0 ${isDarkMode ? 'border-white/5' : 'border-slate-100'}`}
                >
                  {hours.map(hour => (
                    <div 
                      key={hour} 
                      onClick={() => onSlotClick(viewMode === 'day' ? (col as Staff).id : staff[0].id, hour)}
                      className={`border-b group relative cursor-pointer ${isDarkMode ? 'border-white/5 hover:bg-white/[0.03]' : 'border-slate-100 hover:bg-blue-50/30'}`}
                      style={{ height: `${config.rowHeight}px` }}
                    >
                      {columnWidth > 30 && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="p-1 bg-blue-100 text-blue-600 rounded-lg shadow-sm">
                            <Plus className="w-4 h-4" />
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  
                  {appointments
                    .filter(a => viewMode === 'day' 
                      ? (a.staffId === (col as Staff).id && isSameDay(a.startTime, selectedDate))
                      : isSameDay(a.startTime, col as Date)
                    )
                    .map(app => (
                      <AppointmentCard 
                        key={app.id} 
                        app={app} 
                        onEdit={onUpdateAppointment} 
                        cellHeight={config.rowHeight} 
                        config={config} 
                        isDarkMode={isDarkMode}
                        columnWidth={columnWidth}
                      />
                    ))
                  }
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AppointmentCard: React.FC<{ app: Appointment, onEdit: (app: Appointment) => void, cellHeight: number, config: CalendarConfig, isDarkMode?: boolean, columnWidth: number }> = ({ app, onEdit, cellHeight, config, isDarkMode, columnWidth }) => {
  const startHour = app.startTime.getHours();
  const startMin = app.startTime.getMinutes();
  const top = ((startHour - config.startHour) * cellHeight) + (startMin / 60 * cellHeight);
  const service = SERVICES.find(s => s.id === app.serviceId);
  const duration = app.isBlock ? (app.durationOverride || 60) : (service?.duration || 60);
  const height = Math.max(20, (duration / 60) * cellHeight);

  const statusColor = app.isBlock ? 'bg-slate-400' : 'bg-blue-600';

  return (
    <div
      onClick={(e) => { e.stopPropagation(); onEdit(app); }}
      className={`absolute left-[1px] right-[1px] rounded-md shadow-sm transition-all cursor-pointer z-10 overflow-hidden active:scale-[0.98] border flex
        ${app.isBlock 
          ? (isDarkMode ? 'bg-slate-800/80 border-slate-700/50 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-500')
          : (isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900')}
      `}
      style={{ top: `${top}px`, height: `${height}px` }}
    >
      <div className={`w-1 shrink-0 ${statusColor}`} />
      
      {columnWidth > 30 && (
        <div className="flex-1 p-1 min-w-0 flex flex-col justify-center overflow-hidden">
          {height > 40 && columnWidth > 60 && (
            <p className="text-[7px] font-black uppercase tracking-widest text-slate-400 mb-0.5 whitespace-nowrap">
              {format(app.startTime, 'HH:mm')}
            </p>
          )}
          <p className={`font-black tracking-tight truncate leading-none ${columnWidth > 80 ? 'text-[10px]' : 'text-[8px]'}`}>
            {app.customerName}
          </p>
          {!app.isBlock && height > 60 && columnWidth > 70 && (
            <p className="text-[7px] font-bold text-slate-400 truncate mt-0.5">{service?.name}</p>
          )}
        </div>
      )}
    </div>
  );
};

export default CalendarView;
