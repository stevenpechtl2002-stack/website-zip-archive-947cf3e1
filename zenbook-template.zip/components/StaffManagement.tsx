
import React, { useState } from 'react';
import { Staff } from '../types';
import { Mail, Phone, MoreVertical, UserPlus, Star, X, Shield } from 'lucide-react';

interface Props {
  staff: Staff[];
  onAddStaff: (staff: Staff) => void;
  // Added isDarkMode to props
  isDarkMode: boolean;
}

const COLORS = [
  'bg-rose-100 border-rose-200 text-rose-700',
  'bg-emerald-100 border-emerald-200 text-emerald-700',
  'bg-indigo-100 border-indigo-200 text-indigo-700',
  'bg-amber-100 border-amber-200 text-amber-700',
  'bg-sky-100 border-sky-200 text-sky-700',
  'bg-purple-100 border-purple-200 text-purple-700',
];

const StaffManagement: React.FC<Props> = ({ staff, onAddStaff, isDarkMode }) => {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    role: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.role) return;

    const newStaff: Staff = {
      id: 's' + Math.random().toString(36).substr(2, 9),
      name: formData.name,
      role: formData.role,
      avatar: `https://picsum.photos/seed/${formData.name.replace(/\s/g, '')}/200`,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
    };

    onAddStaff(newStaff);
    setShowModal(false);
    setFormData({ name: '', role: '' });
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h3 className={`text-4xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Dein Power-Team</h3>
          <p className="text-slate-500 font-medium mt-2">Verwalte Berechtigungen und Verfügbarkeiten deines Teams mit KI-Unterstützung.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className={`flex items-center gap-3 px-8 py-5 text-white rounded-[2rem] font-black hover:scale-[1.05] transition-all shadow-2xl active:scale-95 ${isDarkMode ? 'bg-gradient-to-r from-blue-600 to-indigo-600 shadow-blue-500/20' : 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 shadow-indigo-200'}`}
        >
          <UserPlus className="w-6 h-6 stroke-[2.5px]" />
          Hinzufügen
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-10">
        {staff.map(member => (
          <div key={member.id} className={`rounded-[3rem] overflow-hidden border shadow-2xl floating-card group ${isDarkMode ? 'bg-white/5 border-white/5' : 'bg-white border-white'}`}>
            <div className={`h-32 relative ${isDarkMode ? 'bg-gradient-to-br from-blue-600 to-indigo-600' : 'bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500'}`}>
               <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
               <button className="absolute top-6 right-6 p-2 bg-white/20 hover:bg-white/40 rounded-2xl text-white backdrop-blur-md transition-all">
                <MoreVertical className="w-5 h-5" />
               </button>
            </div>
            <div className="px-8 pb-10 text-center">
              <div className="relative inline-block -mt-16 mb-6">
                <div className={`p-1.5 rounded-[2.5rem] shadow-2xl ${isDarkMode ? 'bg-black' : 'bg-white'}`}>
                  <img 
                    src={member.avatar} 
                    alt={member.name} 
                    className="w-28 h-28 rounded-[2rem] object-cover"
                  />
                </div>
                <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-emerald-500 border-[6px] border-white rounded-full shadow-lg"></div>
              </div>
              
              <h4 className={`text-2xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{member.name}</h4>
              <p className={`font-black text-xs uppercase tracking-widest mt-1 ${isDarkMode ? 'text-blue-400' : 'text-indigo-600'}`}>{member.role}</p>

              <div className="flex items-center justify-center gap-1.5 mt-4 mb-8">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star key={i} className={`w-4 h-4 ${i <= 4 ? 'fill-yellow-400 text-yellow-400' : 'text-slate-200'}`} />
                ))}
                <span className="text-xs text-slate-500 font-black ml-2">4.8</span>
              </div>

              <div className="flex gap-3">
                <button className={`flex-1 h-14 rounded-2xl transition-all flex items-center justify-center shadow-inner ${isDarkMode ? 'bg-white/5 text-slate-500 hover:text-blue-400 hover:bg-white/10' : 'bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50'}`}>
                  <Mail className="w-6 h-6" />
                </button>
                <button className={`flex-1 h-14 rounded-2xl transition-all flex items-center justify-center shadow-inner ${isDarkMode ? 'bg-white/5 text-slate-500 hover:text-blue-400 hover:bg-white/10' : 'bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50'}`}>
                  <Phone className="w-6 h-6" />
                </button>
                <button className={`flex-[2] h-14 rounded-2xl text-sm font-black transition-all shadow-xl active:scale-95 ${isDarkMode ? 'bg-white text-black hover:bg-blue-600 hover:text-white' : 'bg-slate-900 text-white hover:bg-indigo-600'}`}>
                  Dienstplan
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modern Floating Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xl p-4 animate-in fade-in duration-300">
          <div className={`rounded-[3rem] w-full max-w-md p-12 shadow-2xl animate-in zoom-in-95 duration-300 relative border ${isDarkMode ? 'bg-black border-white/10' : 'bg-white border-white'}`}>
            <button 
              onClick={() => setShowModal(false)}
              className="absolute top-8 right-8 p-3 text-slate-500 hover:text-blue-500 rounded-2xl hover:bg-white/5 transition-all"
            >
              <X className="w-6 h-6" />
            </button>
            <h4 className={`text-3xl font-black mb-10 tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Talent einladen</h4>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2">Vollständiger Name</label>
                <input 
                  type="text" 
                  autoFocus
                  required
                  className={`w-full px-6 py-4 rounded-2xl border-2 border-transparent focus:border-blue-500 outline-none transition-all font-bold shadow-inner ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50 text-slate-700'}`} 
                  placeholder="z.B. Julia Meier"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2">Spezialisierung</label>
                <input 
                  type="text" 
                  required
                  className={`w-full px-6 py-4 rounded-2xl border-2 border-transparent focus:border-blue-500 outline-none transition-all font-bold shadow-inner ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50 text-slate-700'}`} 
                  placeholder="z.B. Color Specialist"
                  value={formData.role}
                  onChange={(e) => setFormData({...formData, role: e.target.value})}
                />
              </div>
              <div className="pt-6">
                <button 
                  type="submit"
                  className={`w-full px-8 py-5 rounded-[2rem] text-white font-black hover:scale-[1.03] active:scale-95 transition-all shadow-2xl flex items-center justify-center gap-3 ${isDarkMode ? 'bg-gradient-to-r from-blue-600 to-indigo-600 shadow-blue-500/20' : 'bg-gradient-to-r from-indigo-600 to-purple-600 shadow-indigo-100'}`}
                >
                  <UserPlus className="w-6 h-6 stroke-[2.5px]" />
                  Bestätigen
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffManagement;
