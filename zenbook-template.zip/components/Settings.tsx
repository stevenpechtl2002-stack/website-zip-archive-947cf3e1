
import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Copy, 
  Smartphone, 
  Lock, 
  Database, 
  Trash2, 
  Cpu,
  Terminal,
  Code,
  ShieldCheck,
  RefreshCw,
  Activity,
  Camera,
  MapPin,
  Store,
  Info,
  Sparkles,
  HelpCircle,
  ChevronRight,
  Image as ImageIcon,
  Upload,
  Users,
  Calendar,
  Zap,
  Clock,
  Layout,
  Link,
  Key,
  Maximize2
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { CalendarConfig } from '../types';

interface Props {
  onSimulateIncoming: (payload: any) => void;
  onConfigChange: (config: CalendarConfig) => void;
  isDarkMode: boolean;
}

const Settings: React.FC<Props> = ({ onSimulateIncoming, onConfigChange, isDarkMode }) => {
  const [webhookUrl, setWebhookUrl] = useState(localStorage.getItem('zenbook_webhook_url') || '');
  const [apiUrl, setApiUrl] = useState(localStorage.getItem('zenbook_external_api_url') || '');
  const [apiKey, setApiKey] = useState(localStorage.getItem('zenbook_external_api_key') || '');
  
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [dbStats, setDbStats] = useState(storageService.getStats());
  const [calConfig, setCalConfig] = useState<CalendarConfig>(storageService.getCalendarConfig());
  
  useEffect(() => {
    const interval = setInterval(() => {
      setDbStats(storageService.getStats());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const triggerSaveFeedback = () => {
    setSaveStatus('saved');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const handleSaveWebhook = () => {
    localStorage.setItem('zenbook_webhook_url', webhookUrl);
    triggerSaveFeedback();
  };

  const handleSaveApiConfig = () => {
    localStorage.setItem('zenbook_external_api_url', apiUrl);
    localStorage.setItem('zenbook_external_api_key', apiKey);
    triggerSaveFeedback();
  };

  const handleSaveCalendar = () => {
    storageService.saveCalendarConfig(calConfig);
    onConfigChange(calConfig);
    triggerSaveFeedback();
  };

  const handleLiveConfigChange = (newConfig: CalendarConfig) => {
    setCalConfig(newConfig);
    onConfigChange(newConfig);
  };

  return (
    <div className="w-full space-y-16 animate-in fade-in duration-700 pb-32">
      
      {/* Header Section */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div>
          <h3 className={`text-5xl font-black tracking-tighter ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>System & Profile</h3>
          <p className="text-slate-500 font-medium mt-3 text-lg">Konfiguriere deinen digitalen Salon und verwalte deine Schnittstellen.</p>
        </div>
        <div className="flex gap-4">
           <div className={`px-6 py-3 rounded-2xl border shadow-sm flex items-center gap-3 ${isDarkMode ? 'bg-white/5 border-white/5' : 'bg-white border-slate-100'}`}>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Server Online</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
        
        {/* LEFT COLUMN: Salon & Content */}
        <div className="xl:col-span-12 space-y-10">
          
          {/* Calendar Customization */}
          <div className={`rounded-[3.5rem] p-12 border shadow-2xl relative overflow-hidden group transition-colors ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-slate-50'}`}>
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/5 rounded-full -mr-48 -mt-48 blur-3xl opacity-40"></div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg ${isDarkMode ? 'bg-blue-600' : 'bg-indigo-600'}`}>
                    <Calendar className="w-7 h-7" />
                  </div>
                  <h4 className={`text-2xl font-black tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Kalender Dimensionen</h4>
                </div>
                <div className="px-6 py-3 bg-indigo-500/10 text-indigo-500 rounded-2xl font-black text-[10px] uppercase tracking-widest">Live Preview Aktiv</div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                {/* Vertical Spacing (Row Height) */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                      <Clock className="w-4 h-4" /> Zeilenhöhe (Dichte)
                    </label>
                    <span className="text-xl font-black text-indigo-600">{calConfig.rowHeight}px</span>
                  </div>
                  <input 
                    type="range"
                    min="20"
                    max="200"
                    step="5"
                    value={calConfig.rowHeight}
                    onChange={(e) => handleLiveConfigChange({...calConfig, rowHeight: parseInt(e.target.value)})}
                    className="w-full h-3 bg-slate-100 rounded-full appearance-none cursor-pointer accent-indigo-600"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
                    <span>Kompakt</span>
                    <span>Großzügig</span>
                  </div>
                </div>

                {/* Horizontal Spacing (Column Width) */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                      <Maximize2 className="w-4 h-4" /> Spaltenbreite (Mitarbeiter)
                    </label>
                    <span className="text-xl font-black text-indigo-600">{calConfig.columnWidth}px</span>
                  </div>
                  <input 
                    type="range"
                    min="10"
                    max="400"
                    step="1"
                    value={calConfig.columnWidth}
                    onChange={(e) => handleLiveConfigChange({...calConfig, columnWidth: parseInt(e.target.value)})}
                    className="w-full h-3 bg-slate-100 rounded-full appearance-none cursor-pointer accent-indigo-600"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">
                    <span>10px</span>
                    <span>400px</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Arbeitsbeginn</label>
                  <select 
                    value={calConfig.startHour}
                    onChange={(e) => handleLiveConfigChange({...calConfig, startHour: parseInt(e.target.value)})}
                    className={`w-full px-8 py-5 rounded-[1.8rem] border-2 border-transparent focus:border-blue-500 outline-none font-bold transition-all appearance-none ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50 text-slate-700'}`}
                  >
                    {Array.from({length: 12}, (_, i) => i).map(h => <option key={h} value={h} className={isDarkMode ? "bg-slate-900" : ""}>{h}:00 Uhr</option>)}
                  </select>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Arbeitsende</label>
                  <select 
                    value={calConfig.endHour}
                    onChange={(e) => handleLiveConfigChange({...calConfig, endHour: parseInt(e.target.value)})}
                    className={`w-full px-8 py-5 rounded-[1.8rem] border-2 border-transparent focus:border-blue-500 outline-none font-bold transition-all appearance-none ${isDarkMode ? 'bg-white/5 text-white' : 'bg-slate-50 text-slate-700'}`}
                  >
                    {Array.from({length: 12}, (_, i) => i + 12).map(h => <option key={h} value={h} className={isDarkMode ? "bg-slate-900" : ""}>{h}:00 Uhr</option>)}
                  </select>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t flex items-center justify-between">
                <p className="text-sm font-medium text-slate-400 max-w-md">Die Änderungen werden in Echtzeit übernommen. Klicke auf Speichern, um sie dauerhaft für diesen Salon zu sichern.</p>
                <button 
                  onClick={handleSaveCalendar}
                  className={`px-12 py-5 text-white rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] hover:opacity-90 transition-all shadow-xl active:scale-95 flex items-center gap-3 ${isDarkMode ? 'bg-blue-600' : 'bg-indigo-600'}`}
                >
                  {saveStatus === 'saved' ? <CheckCircle2 className="w-5 h-5 text-emerald-300" /> : <Sparkles className="w-5 h-5" />}
                  Konfiguration dauerhaft speichern
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
