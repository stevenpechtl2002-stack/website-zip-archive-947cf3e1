
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  Calendar, 
  Activity,
  Zap,
  ArrowUpRight,
  TrendingDown,
  Clock
} from 'lucide-react';
import { Appointment, Service, Staff } from '../types';
import { getBusinessInsights } from '../services/geminiService';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format, isToday, isFuture, startOfDay, subDays } from 'date-fns';
import { de } from 'date-fns/locale';

interface Props {
  appointments: Appointment[];
  services: Service[];
  staff: Staff[];
  isDarkMode: boolean;
}

const Insights: React.FC<Props> = ({ appointments, services, staff, isDarkMode }) => {
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<{
    summary: string;
    tips: string[];
    nextWeekOutlook: string;
  } | null>(null);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const data = await getBusinessInsights(appointments, services, staff);
        setInsights(data);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [appointments]);

  const stats = useMemo(() => {
    const today = appointments.filter(a => isToday(a.startTime));
    const upcoming = appointments.filter(a => isFuture(a.startTime));
    const revenue = appointments.reduce((acc, curr) => {
      const s = services.find(serv => serv.id === curr.serviceId);
      return acc + (s?.price || 0);
    }, 0);
    
    return { today: today.length, upcoming: upcoming.length, revenue };
  }, [appointments, services]);

  const dailyData = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => subDays(new Date(), 6 - i)).map(day => {
      const dayApps = appointments.filter(a => startOfDay(a.startTime).getTime() === startOfDay(day).getTime());
      return {
        name: format(day, 'EEE', { locale: de }),
        revenue: dayApps.reduce((acc, curr) => acc + (services.find(s => s.id === curr.serviceId)?.price || 0), 0)
      };
    });
  }, [appointments, services]);

  return (
    <div className="space-y-16 animate-in fade-in duration-1000">
      
      {/* Bento Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <div className={`col-span-1 lg:col-span-2 rounded-[3.5rem] p-12 shadow-3xl overflow-hidden relative group transition-all ${isDarkMode ? 'bg-slate-900 border border-white/10 text-white' : 'bg-indigo-600 text-white shadow-indigo-200'}`}>
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-pink-500/20 blur-[100px] transition-all group-hover:scale-125 duration-1000"></div>
          <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-400/10 blur-[80px] rounded-full"></div>
          
          <div className="relative z-10 flex justify-between items-start mb-16">
             <div className="p-5 bg-white/10 rounded-2xl backdrop-blur-xl border border-white/10 shadow-inner">
                <TrendingUp className="w-8 h-8 text-white" />
             </div>
             <ArrowUpRight className="w-8 h-8 text-white/40 group-hover:text-white transition-colors" />
          </div>
          <div className="relative z-10">
             <p className="text-[11px] font-black uppercase tracking-[0.4em] text-white/60 mb-4">Umsatz Total</p>
             <h4 className="text-8xl font-black tracking-tighter leading-none">{stats.revenue.toLocaleString('de-DE')} €</h4>
             <div className="mt-8 flex items-center gap-2 text-indigo-100 font-bold text-sm bg-white/10 w-fit px-4 py-2 rounded-full backdrop-blur-md">
                <TrendingUp className="w-4 h-4 text-emerald-400" /> +14.2% Trend
             </div>
          </div>
        </div>

        <div className={`rounded-[3.5rem] p-12 shadow-2xl border flex flex-col justify-between group transition-colors ${isDarkMode ? 'bg-slate-900 border-white/10' : 'bg-white border-indigo-50 shadow-[0_32px_64px_-16px_rgba(99,102,241,0.06)]'}`}>
           <div className={`p-5 rounded-2xl w-fit shadow-sm ${isDarkMode ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
              <Calendar className="w-8 h-8" />
           </div>
           <div className="mt-12">
              <p className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-400 mb-4">Heute</p>
              <h4 className={`text-6xl font-black tracking-tighter ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{stats.today}</h4>
              <p className="text-sm font-bold text-slate-400 mt-2">Buchungen</p>
           </div>
        </div>

        <div className={`rounded-[3.5rem] p-12 shadow-2xl border flex flex-col justify-between group transition-colors ${isDarkMode ? 'bg-slate-900 border-white/10' : 'bg-white border-purple-50 shadow-[0_32px_64px_-16px_rgba(168,85,247,0.06)]'}`}>
           <div className={`p-5 rounded-2xl w-fit shadow-sm ${isDarkMode ? 'bg-purple-500/20 text-purple-400' : 'bg-purple-50 text-purple-600'}`}>
              <Zap className="w-8 h-8" />
           </div>
           <div className="mt-12">
              <p className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-400 mb-4">Warteliste</p>
              <h4 className={`text-6xl font-black tracking-tighter ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{stats.upcoming}</h4>
              <p className="text-sm font-bold text-slate-400 mt-2">Potenzial</p>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className={`lg:col-span-2 rounded-[4rem] p-16 shadow-2xl border transition-colors ${isDarkMode ? 'bg-slate-900 border-white/10' : 'bg-white border-indigo-50 shadow-[0_32px_64px_-16px_rgba(99,102,241,0.06)]'}`}>
          <div className="flex items-center justify-between mb-20">
             <div>
                <h4 className={`text-3xl font-black tracking-tighter flex items-center gap-4 ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                  <Activity className="w-8 h-8 text-indigo-500" /> Wachstumskurve
                </h4>
                <p className="text-slate-400 font-bold mt-2">Letzte 7 Tage im Überblick</p>
             </div>
          </div>
          <div className="h-[450px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 800}} dy={15} />
                <Tooltip 
                  cursor={{stroke: '#6366f1', strokeWidth: 2, strokeDasharray: '4 4'}}
                  contentStyle={{borderRadius: '32px', border: 'none', boxShadow: '0 40px 80px rgba(0,0,0,0.1)', padding: '20px', backgroundColor: isDarkMode ? '#1a1a1a' : '#fff', color: isDarkMode ? '#fff' : '#000'}} 
                />
                <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={6} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className={`rounded-[4rem] p-16 text-white shadow-3xl relative overflow-hidden flex flex-col transition-colors ${isDarkMode ? 'bg-indigo-950/40 border border-indigo-500/20' : 'bg-slate-900'}`}>
          <div className="absolute top-0 right-0 w-80 h-80 bg-pink-500/10 rounded-full blur-[100px] -mr-40 -mt-40"></div>
          
          <div className="relative z-10 flex-1">
            <div className="flex items-center gap-4 mb-16">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center border border-white/10">
                <Sparkles className="w-6 h-6 text-indigo-400" />
              </div>
              <h4 className="text-[11px] font-black uppercase tracking-[0.4em] text-indigo-400">KI Business Coach</h4>
            </div>

            {loading ? (
              <div className="space-y-8 animate-pulse">
                <div className="h-6 bg-white/5 rounded-full w-3/4"></div>
                <div className="h-6 bg-white/5 rounded-full w-full"></div>
                <div className="h-20 bg-white/5 rounded-[2rem] w-full"></div>
              </div>
            ) : (
              <div className="space-y-12">
                 <p className="text-3xl font-black leading-[1.2] text-white tracking-tight">
                   "{insights?.summary || 'Analysiere Daten...'}"
                 </p>
                 <div className="space-y-4">
                    {insights?.tips.slice(0, 2).map((tip, i) => (
                      <div key={i} className="flex gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                         <Zap className="w-5 h-5 text-amber-400 shrink-0" />
                         <p className="text-xs font-bold text-white/70 leading-relaxed">{tip}</p>
                      </div>
                    ))}
                 </div>
              </div>
            )}
          </div>

          <button className={`w-full py-6 mt-16 rounded-[2rem] font-black text-[11px] uppercase tracking-[0.3em] hover:scale-[1.03] transition-all relative z-10 shadow-2xl active:scale-95 bg-white text-slate-900`}>
             Strategieplan laden
          </button>
        </div>
      </div>
    </div>
  );
};

export default Insights;
