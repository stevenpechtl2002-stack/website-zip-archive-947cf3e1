
import React, { useState, useMemo } from 'react';
import { SALONS, SERVICES } from '../constants';
import { 
  LogOut, 
  Search, 
  MapPin, 
  Star, 
  ArrowRight,
  SlidersHorizontal,
  Plus,
  Compass,
  Heart,
  Calendar,
  Clock,
  Navigation
} from 'lucide-react';
import { Salon, BeautyCategory } from '../types';

interface Props {
  onLogout: () => void;
}

const CustomerPortal: React.FC<Props> = ({ onLogout }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<BeautyCategory | 'Alle'>('Alle');
  const [viewedSalon, setViewedSalon] = useState<Salon | null>(null);
  const isDark = document.body.classList.contains('theme-dark');

  const categories: (BeautyCategory | 'Alle')[] = ['Alle', 'Friseur', 'Nägel', 'Haarentfernung', 'Massage', 'Gesichtsbehandlung'];

  const filteredSalons = useMemo(() => {
    return SALONS.filter(salon => {
      const matchesSearch = salon.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          salon.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'Alle' || salon.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <div className={`min-h-screen selection:bg-blue-500 selection:text-white transition-colors duration-500 ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Editorial Header */}
      <header className={`fixed top-0 left-0 right-0 backdrop-blur-3xl z-[100] border-b transition-colors duration-500 ${isDark ? 'bg-black/80 border-white/10' : 'bg-white/80 border-black/5'}`}>
        <div className="max-w-[1800px] mx-auto px-12 h-24 flex items-center justify-between">
          <div className="flex items-center gap-12">
            <div className="flex items-center gap-3 group cursor-pointer" onClick={() => setViewedSalon(null)}>
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-black text-xl transition-all group-hover:scale-110 ${isDark ? 'bg-white text-black' : 'bg-black text-white'}`}>Z</div>
              <h1 className="text-2xl font-black tracking-tighter">ZenBook <span className="text-blue-600">Beauty</span></h1>
            </div>
            
            <nav className="hidden lg:flex items-center gap-8">
              {['Entdecken', 'Marktplatz', 'Angebote'].map(item => (
                <button key={item} className={`text-sm font-black uppercase tracking-widest transition-colors ${isDark ? 'text-white/40 hover:text-white' : 'text-slate-400 hover:text-black'}`}>{item}</button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-6">
            <button className={`p-4 rounded-2xl transition-all ${isDark ? 'bg-white/5 text-white/40 hover:text-white' : 'bg-slate-50 text-slate-400 hover:text-black'}`}>
              <Heart className="w-5 h-5" />
            </button>
            <button 
              onClick={onLogout}
              className={`flex items-center gap-3 px-8 py-4 rounded-full font-black text-xs uppercase tracking-[0.2em] transition-all active:scale-95 ${isDark ? 'bg-white text-black hover:bg-blue-600 hover:text-white' : 'bg-black text-white hover:bg-blue-600'}`}
            >
              Abmelden
            </button>
          </div>
        </div>
      </header>

      <main className="pt-40 pb-32">
        {viewedSalon ? (
          /* Salon Luxury Detail View */
          <div className="max-w-[1600px] mx-auto px-12 animate-in fade-in duration-700">
            <button 
              onClick={() => setViewedSalon(null)}
              className="mb-12 flex items-center gap-3 text-xs font-black uppercase tracking-[0.3em] text-slate-400 hover:text-black transition-all"
            >
              <ArrowRight className="w-5 h-5 rotate-180" /> Zurück zur Suche
            </button>
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
              <div className="lg:col-span-8 space-y-20">
                <div className="relative h-[600px] rounded-[5rem] overflow-hidden shadow-3xl">
                  <img src={viewedSalon.image} className="w-full h-full object-cover" alt={viewedSalon.name} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                  <div className="absolute bottom-20 left-20">
                    <span className="px-6 py-2 bg-blue-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest">{viewedSalon.category}</span>
                    <h2 className="text-7xl font-black text-white mt-8 tracking-tighter">{viewedSalon.name}</h2>
                    <div className="flex items-center gap-8 mt-6 text-white/60 font-black text-sm uppercase tracking-widest">
                       <div className="flex items-center gap-2"><MapPin className="w-5 h-5" /> {viewedSalon.location}</div>
                       <div className="flex items-center gap-2"><Star className="w-5 h-5 text-yellow-400 fill-yellow-400" /> {viewedSalon.rating}</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-12">
                   <h3 className="text-5xl font-black tracking-tighter">Verfügbare Behandlungen</h3>
                   <div className="grid grid-cols-1 gap-6">
                      {SERVICES.filter(s => s.category === viewedSalon.category || s.category === 'Wellness').map(service => (
                        <div key={service.id} className={`p-10 rounded-[3rem] flex justify-between items-center group transition-all ${isDark ? 'bg-white/5 hover:bg-white hover:text-black' : 'bg-[#f5f5f7] hover:bg-black hover:text-white'}`}>
                           <div>
                              <h4 className="text-2xl font-black mb-2">{service.name}</h4>
                              <p className="text-sm font-bold opacity-40 uppercase tracking-widest">{service.duration} Min • Inkl. Beratung</p>
                           </div>
                           <div className="flex items-center gap-12">
                              <span className="text-3xl font-black">{service.price}€</span>
                              <button className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-xl transition-all ${isDark ? 'bg-white text-black group-hover:bg-blue-600 group-hover:text-white' : 'bg-white text-black group-hover:bg-blue-600 group-hover:text-white'}`}>
                                 <Plus className="w-8 h-8" />
                              </button>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              </div>

              <div className="lg:col-span-4 space-y-10">
                 <div className={`p-12 rounded-[4rem] shadow-3xl sticky top-40 ${isDark ? 'bg-white/10 text-white' : 'bg-black text-white'}`}>
                    <h4 className="text-2xl font-black mb-10 tracking-tight">Express Buchung</h4>
                    <div className="space-y-8">
                       <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                          <p className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-2">Nächster freier Termin</p>
                          <div className="flex items-center gap-3 text-xl font-bold">
                             <Calendar className="w-5 h-5 text-blue-400" /> Heute, 16:45 Uhr
                          </div>
                       </div>
                       <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                          <p className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-2">Salon Info</p>
                          <div className="flex items-center gap-3 text-xl font-bold">
                             <Clock className="w-5 h-5 text-emerald-400" /> Geöffnet bis 20:00
                          </div>
                       </div>
                    </div>
                    <button className="w-full mt-12 py-8 bg-blue-600 rounded-[2rem] font-black text-sm uppercase tracking-[0.4em] hover:bg-blue-700 transition-all shadow-3xl shadow-blue-500/20 active:scale-95">
                       Jetzt Termin wählen
                    </button>
                    <p className="text-center text-[10px] font-black text-white/20 mt-10 uppercase tracking-[0.5em]">Keine Stornogebühren</p>
                 </div>
              </div>
            </div>
          </div>
        ) : (
          /* Marketplace Discovery View */
          <div className="max-w-[1800px] mx-auto px-12 space-y-32">
            {/* Hero Search */}
            <div className="text-center space-y-16">
               <h2 className="text-8xl md:text-[12rem] font-black tracking-tighter leading-none">
                  Finde dein <br />
                  <span className="text-blue-600">Leuchten.</span>
               </h2>
               
               <div className="max-w-4xl mx-auto relative group">
                  <div className="absolute inset-0 bg-blue-500/5 blur-3xl rounded-[4rem]"></div>
                  <div className={`relative rounded-[3.5rem] p-4 flex flex-col md:flex-row items-center gap-4 border shadow-2xl transition-colors duration-500 ${isDark ? 'bg-white/5 border-white/10' : 'bg-[#f5f5f7] border-black/5'}`}>
                     <div className="flex-1 flex items-center px-8 w-full">
                        <Search className="w-6 h-6 text-slate-300 mr-6" />
                        <input 
                          type="text" 
                          placeholder="Behandlung oder Ort suchen..."
                          className="w-full bg-transparent py-6 outline-none font-black text-xl placeholder:text-slate-300"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                     </div>
                     <button className={`w-full md:w-auto px-16 py-6 rounded-[2.5rem] font-black uppercase tracking-[0.3em] transition-all shadow-2xl ${isDark ? 'bg-white text-black hover:bg-blue-600 hover:text-white' : 'bg-black text-white hover:bg-blue-600'}`}>
                        Finden
                     </button>
                  </div>
               </div>

               {/* Luxury Filter Pills */}
               <div className="flex flex-wrap justify-center gap-4">
                  {categories.map(cat => (
                    <button 
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-10 py-5 rounded-full text-[11px] font-black uppercase tracking-widest transition-all ${selectedCategory === cat ? (isDark ? 'bg-white text-black shadow-2xl scale-110' : 'bg-black text-white shadow-2xl scale-110') : (isDark ? 'bg-white/5 text-white/40 hover:text-white' : 'bg-[#f5f5f7] text-slate-400 hover:text-black')}`}
                    >
                      {cat}
                    </button>
                  ))}
               </div>
            </div>

            {/* Salon Grid */}
            <div className="space-y-16">
               <div className={`flex items-center justify-between border-b pb-10 transition-colors duration-500 ${isDark ? 'border-white/10' : 'border-black/5'}`}>
                  <h3 className="text-4xl font-black tracking-tighter">{filteredSalons.length} Premium Salons</h3>
                  <button className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-slate-400">
                    <SlidersHorizontal className="w-5 h-5" /> Filter anpassen
                  </button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
                  {filteredSalons.map(salon => (
                    <div 
                      key={salon.id} 
                      onClick={() => setViewedSalon(salon)}
                      className="group relative cursor-pointer reveal"
                    >
                       <div className="aspect-[4/5] rounded-[5rem] overflow-hidden shadow-2xl mb-10 relative">
                          <img 
                            src={salon.image} 
                            className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-110" 
                            alt={salon.name} 
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                          <div className="absolute bottom-12 left-12 opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0">
                             <button className="px-12 py-5 bg-white text-black rounded-full font-black text-[10px] uppercase tracking-widest shadow-3xl">
                                Salon ansehen
                             </button>
                          </div>
                       </div>
                       
                       <div className="px-6 space-y-4">
                          <div className="flex justify-between items-start">
                             <h4 className="text-3xl font-black tracking-tighter">{salon.name}</h4>
                             <div className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-600 rounded-full font-black text-xs">
                                <Star className="w-3 h-3 fill-blue-600" /> {salon.rating}
                             </div>
                          </div>
                          <div className={`flex items-center justify-between text-sm font-black uppercase tracking-widest ${isDark ? 'text-white/40' : 'text-slate-300'}`}>
                             <span>{salon.location}</span>
                             <span className="text-blue-600">{salon.priceLevel}</span>
                          </div>
                          <p className="text-slate-400 font-bold line-clamp-2 leading-relaxed">
                             {salon.reviews} verifizierte ZenBook-Bewertungen sprechen für sich.
                          </p>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        )}
      </main>

      {/* Modern Marketplace Footer */}
      <footer className={`py-40 rounded-t-[10rem] transition-colors duration-500 ${isDark ? 'bg-white/5' : 'bg-[#f5f5f7]'}`}>
         <div className="max-w-[1800px] mx-auto px-12 grid grid-cols-1 md:grid-cols-4 gap-24">
            <div className="md:col-span-2 space-y-12">
               <h2 className="text-6xl font-black tracking-tighter">Bereit für dein <br /> <span className="text-blue-600">Beauty-Erlebnis?</span></h2>
               <p className="text-2xl text-slate-400 font-medium max-w-md">Die besten Salons Deutschlands direkt in deiner Hand. Sicher, schnell und exklusiv.</p>
            </div>
            <div className="space-y-8">
               <h5 className={`text-[11px] font-black uppercase tracking-[0.4em] ${isDark ? 'text-white/30' : 'text-black'}`}>Unternehmen</h5>
               <nav className="flex flex-col gap-4">
                  {['Über uns', 'Karriere', 'Partner werden'].map(l => (
                    <button key={l} className="w-fit text-sm font-bold text-slate-400 hover:text-black transition-colors">{l}</button>
                  ))}
               </nav>
            </div>
            <div className="space-y-8">
               <h5 className={`text-[11px] font-black uppercase tracking-[0.4em] ${isDark ? 'text-white/30' : 'text-black'}`}>Support</h5>
               <nav className="flex flex-col gap-4">
                  {['Häufige Fragen', 'Kontakt', 'Sicherheit'].map(l => (
                    <button key={l} className="w-fit text-sm font-bold text-slate-400 hover:text-black transition-colors">{l}</button>
                  ))}
               </nav>
            </div>
         </div>
      </footer>
    </div>
  );
};

export default CustomerPortal;
