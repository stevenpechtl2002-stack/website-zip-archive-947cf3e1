
import React, { useRef, useEffect, useState } from 'react';
import { UserRole } from '../types';
import { 
  ArrowRight, 
  Sparkles, 
  User, 
  Users,
  Store, 
  ChevronDown,
  Search,
  MapPin,
  Monitor,
  MousePointer2,
  Globe,
  Zap,
  Scissors,
  CheckCircle,
  Camera,
  Heart
} from 'lucide-react';

interface Props {
  onLogin: (role: UserRole) => void;
  onStartRegistration: () => void;
}

const Login: React.FC<Props> = ({ onLogin, onStartRegistration }) => {
  const selectionRef = useRef<HTMLDivElement>(null);
  const [scrolled, setScrolled] = useState(false);
  const isDark = document.body.classList.contains('theme-dark');

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      observer.disconnect();
    };
  }, []);

  const scrollToSelection = () => {
    selectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const Logo = ({ light = false }) => (
    <div className="flex items-center gap-3 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-black text-xl shadow-2xl transition-all group-hover:scale-110 ${light ? 'bg-white text-black' : (isDark ? 'bg-indigo-500 text-white' : 'bg-indigo-600 text-white')}`}>Z</div>
      <h1 className="text-2xl font-black tracking-tighter">
        <span className={light ? "text-white" : (isDark ? "text-white" : "text-slate-900")}>ZenBook</span> <span className="text-indigo-500">Beauty</span>
      </h1>
    </div>
  );

  return (
    <div className={`overflow-x-hidden selection:bg-indigo-500 selection:text-white transition-colors duration-500 ${isDark ? 'bg-slate-950 text-white' : 'bg-[#f8fafc] text-slate-900'}`}>
      
      {/* Editorial Navigation */}
      <nav className={`fixed top-0 left-0 right-0 h-24 flex items-center px-12 z-[100] transition-all duration-700 ${scrolled ? (isDark ? 'bg-slate-950/80 border-b border-white/5 shadow-2xl' : 'bg-white/80 border-b border-indigo-50 shadow-sm') + ' backdrop-blur-3xl' : 'bg-transparent'}`}>
        <div className="max-w-[1800px] mx-auto w-full flex items-center justify-between">
          <Logo />
          
          <div className="flex items-center gap-10">
            <button 
              onClick={() => onLogin('customer')}
              className={`text-[11px] font-black uppercase tracking-[0.3em] transition-all ${isDark ? 'text-white/50 hover:text-white' : 'text-slate-400 hover:text-indigo-600'}`}
            >
              Kunden Portal
            </button>
            <button 
              onClick={() => onLogin('salon')}
              className={`px-12 py-4 rounded-full text-[11px] font-black uppercase tracking-[0.3em] transition-all active:scale-95 shadow-2xl ${isDark ? 'bg-white text-black hover:bg-indigo-500 hover:text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
            >
              Business Login
            </button>
          </div>
        </div>
      </nav>

      {/* SECTION 1: HERO - SEARCH & BRANDING WITH VIVID ANIMATED BACKGROUND */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-32 pb-20 overflow-hidden">
        
        {/* ENHANCED ANIMATED BACKGROUND WRAPPER */}
        <div className="absolute inset-0 z-0">
          {/* High-Impact Background Image with Ken Burns Effect */}
          <div className="absolute inset-0 scale-110">
            <img 
              src="https://images.unsplash.com/photo-1600948836101-f9ffda59d250?auto=format&fit=crop&q=80&w=2000" 
              className={`w-full h-full object-cover animate-kenburns transition-opacity duration-1000 ${isDark ? 'opacity-30' : 'opacity-[0.25]'}`} 
              alt="Luxury Beauty Background" 
            />
          </div>
          
          {/* Floating Light Blobs for Depth */}
          <div className="absolute top-[10%] left-[5%] w-[1000px] h-[1000px] bg-indigo-500/20 rounded-full blur-[200px] animate-slow-pulse"></div>
          <div className="absolute bottom-[10%] right-[5%] w-[1000px] h-[1000px] bg-pink-500/20 rounded-full blur-[200px] animate-slow-pulse" style={{ animationDelay: '-7s' }}></div>

          {/* Complex Gradient Masking for Content Clarity */}
          <div className={`absolute inset-0 ${isDark ? 'bg-gradient-to-b from-slate-950/40 via-slate-950/80 to-slate-950' : 'bg-gradient-to-b from-white/10 via-[#f8fafc]/70 to-[#f8fafc]'}`}></div>
          <div className={`absolute inset-0 bg-gradient-to-r ${isDark ? 'from-slate-950 via-transparent to-slate-950 opacity-60' : 'from-white via-transparent to-white opacity-40'}`}></div>
        </div>

        {/* Hero Content */}
        <div className="text-center space-y-16 reveal w-full max-w-5xl z-10">
          <div className="space-y-6">
            <h2 className="text-lg md:text-xl font-black text-indigo-500 tracking-[0.6em] uppercase drop-shadow-sm">Ready for your Glow?</h2>
            <h1 className="text-6xl md:text-[7.5rem] font-black tracking-tighter leading-none text-reveal drop-shadow-2xl">
              Alles für dein <br /> Wohlbefinden.
            </h1>
          </div>

          {/* Luxury Search Mask with Glassmorphism */}
          <div className="max-w-4xl mx-auto relative group">
            <div className="absolute -inset-2 bg-gradient-to-r from-indigo-500 via-pink-500 to-amber-500 rounded-[3.5rem] blur-xl opacity-20 group-hover:opacity-50 transition duration-1000"></div>
            <div className={`relative rounded-[3.5rem] p-5 flex flex-col md:flex-row items-center gap-3 border shadow-3xl backdrop-blur-3xl ${isDark ? 'bg-slate-900/80 border-white/10' : 'bg-white/95 border-indigo-50'}`}>
              <div className="flex-1 flex items-center px-10 w-full md:border-r border-slate-200/20">
                <Search className="w-7 h-7 text-indigo-400 mr-6 shrink-0" />
                <input 
                  type="text" 
                  placeholder="Welche Behandlung?"
                  className="w-full bg-transparent py-6 outline-none font-bold text-2xl placeholder:text-slate-300"
                />
              </div>
              <div className="flex-1 flex items-center px-10 w-full">
                <MapPin className="w-7 h-7 text-pink-400 mr-6 shrink-0" />
                <input 
                  type="text" 
                  placeholder="In welcher Stadt?"
                  className="w-full bg-transparent py-6 outline-none font-bold text-2xl placeholder:text-slate-300"
                />
              </div>
              <button 
                onClick={() => onLogin('customer')}
                className="w-full md:w-auto px-16 py-7 bg-gradient-to-br from-indigo-600 to-indigo-900 text-white rounded-[2.5rem] font-black uppercase tracking-[0.4em] text-xs hover:scale-[1.02] transition-all shadow-2xl shadow-indigo-500/40 active:scale-95 shrink-0"
              >
                Suchen
              </button>
            </div>
          </div>

          <p className={`text-2xl font-medium max-w-2xl mx-auto leading-relaxed drop-shadow-sm ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Über 5.000 verifizierte Salons. Einfach buchen, entspannt genießen. <br />
            Dein Termin, deine Zeit.
          </p>
        </div>

        <button onClick={scrollToSelection} className={`absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce opacity-30 ${isDark ? 'text-white' : 'text-slate-900'}`}>
           <ChevronDown className="w-14 h-14" />
        </button>
      </section>

      {/* SECTION 2: SINGLE HERO INSPIRATION IMAGE */}
      <section className="py-40 px-6 max-w-[1600px] mx-auto">
        <div className="flex flex-col md:flex-row items-end justify-between mb-20 gap-8">
          <div className="reveal">
            <h2 className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.6em] mb-4">Inspiration</h2>
            <h3 className="text-5xl md:text-7xl font-black tracking-tighter leading-none">Bereit für eine <br /> Veränderung?</h3>
          </div>
          <button 
            onClick={() => onLogin('customer')}
            className="flex items-center gap-4 text-sm font-black uppercase tracking-[0.3em] hover:text-indigo-500 transition-colors reveal group"
          >
            Alle Styles entdecken <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
          </button>
        </div>

        <div className="reveal">
          <div className="group relative overflow-hidden rounded-[5rem] shadow-3xl bg-slate-200 aspect-[21/9] transition-all hover:scale-[0.99]">
            <img 
              src="https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?auto=format&fit=crop&q=80&w=1600" 
              className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-105" 
              alt="Friseur Salon" 
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/20 to-transparent"></div>
            
            <div className="absolute inset-0 flex flex-col justify-center px-12 md:px-24">
              <span className="px-8 py-3 bg-indigo-600 text-white w-fit rounded-full text-[11px] font-black uppercase tracking-[0.2em] mb-8 shadow-xl">
                Kategorie: Friseur
              </span>
              <h4 className="text-5xl md:text-8xl font-black text-white tracking-tighter leading-none mb-6">
                Exzellenz in <br /> jedem Schnitt.
              </h4>
              <p className="text-xl md:text-2xl text-white/70 font-medium max-w-xl leading-relaxed">
                Entdecke die besten Stylisten deiner Stadt und buche deinen Termin in Sekunden. <br className="hidden md:block" />
                Qualität, die man sieht und fühlt.
              </p>
              
              <button 
                onClick={() => onLogin('customer')}
                className="mt-12 flex items-center gap-6 w-fit bg-white text-slate-900 px-12 py-6 rounded-full font-black text-[11px] uppercase tracking-[0.3em] hover:bg-indigo-600 hover:text-white transition-all shadow-2xl active:scale-95"
              >
                Salon finden <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: FOR SALONS - BENTO EDITORIAL WITH IMAGE */}
      <section className={`py-60 px-12 transition-all ${isDark ? 'bg-slate-900/50' : 'bg-white shadow-inner'}`}>
        <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-40 items-center">
           <div className="reveal">
              <h2 className="text-8xl md:text-[10rem] font-black tracking-tighter leading-[0.9] mb-16 text-indigo-600">
                 Wachstum <br /> als Standard.
              </h2>
              <p className="text-2xl md:text-3xl text-slate-400 font-medium leading-tight mb-20">
                 Die leistungsstärkste Suite für moderne Salons. <br />
                 Vollständig integriert in das exklusivste <br />
                 Buchungs-Netzwerk Deutschlands.
              </p>
              <div className="space-y-12">
                 {[
                   { title: 'Management Suite', desc: 'Manage Buchungen, Team und Kasse an einem Ort.', icon: <Monitor className="w-8 h-8 text-indigo-500" /> },
                   { title: 'Business Insights', desc: 'KI-gestützte Analysen zur Umsatzmaximierung.', icon: <Zap className="w-8 h-8 text-amber-500" /> },
                   { title: 'Global Visibility', desc: 'Präsentiere deinen Salon vor Millionen von Kunden.', icon: <Globe className="w-8 h-8 text-pink-500" /> }
                 ].map(f => (
                   <div key={f.title} className="flex gap-8 group">
                      <div className={`w-16 h-16 rounded-3xl flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-xl border ${isDark ? 'bg-white/5 border-white/5' : 'bg-slate-50 border-indigo-50'}`}>
                         {f.icon}
                      </div>
                      <div>
                         <h4 className="text-2xl font-black tracking-tight mb-2">{f.title}</h4>
                         <p className="text-xl text-slate-400 font-medium">{f.desc}</p>
                      </div>
                   </div>
                 ))}
              </div>
           </div>

           <div className="reveal relative aspect-square">
              <div className="absolute inset-0 bg-indigo-500/10 blur-[150px] rounded-full"></div>
              <div className="group relative h-full rounded-[6rem] overflow-hidden shadow-3xl">
                <img 
                  src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=1200" 
                  className="w-full h-full object-cover transition-transform duration-[3s] group-hover:scale-110" 
                  alt="Business Salon Management"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                <div className="absolute bottom-16 left-16 right-16">
                  <div className="p-8 bg-white/10 backdrop-blur-2xl border border-white/20 rounded-[3rem] shadow-2xl">
                     <div className="flex items-center gap-6 mb-4">
                        <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
                        <span className="text-[10px] font-black text-white uppercase tracking-[0.4em]">Live Dashboard Active</span>
                     </div>
                     <p className="text-xl font-black text-white tracking-tight">Optimiert für maximalen Salon-Erfolg.</p>
                  </div>
                </div>
              </div>
           </div>
        </div>
      </section>

      {/* THE FINAL CHOICE SECTION */}
      <section ref={selectionRef} className={`py-80 px-12 relative border-t ${isDark ? 'bg-slate-950 border-white/5' : 'bg-[#f8fafc] border-indigo-50'}`}>
        <div className="max-w-[1600px] mx-auto text-center mb-60 reveal">
           <h2 className="text-8xl md:text-[14rem] font-black tracking-tighter text-reveal mb-16 leading-tight">Dein Ziel.</h2>
           <p className={`text-3xl md:text-5xl font-medium ${isDark ? 'text-white/20' : 'text-slate-900/10'}`}>Was möchtest du heute bewegen?</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-[1400px] mx-auto">
          <button 
            onClick={() => onLogin('customer')}
            className={`group relative h-[800px] rounded-[6rem] overflow-hidden text-left shadow-3xl reveal transition-all hover:scale-[1.03] active:scale-95 border bg-white text-slate-900 border-indigo-50`}
          >
            <div className="relative h-full flex flex-col justify-end p-24">
               <div className="w-24 h-24 bg-indigo-600 rounded-3xl flex items-center justify-center text-white mb-12 shadow-3xl shadow-indigo-200">
                 <MousePointer2 className="w-12 h-12" />
               </div>
               <h3 className="text-6xl font-black tracking-tighter mb-6">Kunden.</h3>
               <p className="text-slate-400 text-2xl font-bold mb-16 max-w-sm">Finde die besten Beauty-Experten in deiner Nähe.</p>
               <div className="flex items-center gap-6 text-[11px] font-black text-white uppercase tracking-[0.5em] bg-indigo-600 w-full py-8 rounded-[2rem] justify-center shadow-2xl group-hover:bg-indigo-700 transition-all">
                 Marktplatz Login <ArrowRight className="w-6 h-6" />
               </div>
            </div>
          </button>

          <button 
            onClick={() => onLogin('salon')}
            className={`group relative h-[800px] rounded-[6rem] overflow-hidden text-left shadow-3xl reveal transition-all hover:scale-[1.03] active:scale-95 border bg-slate-900 text-white border-white/5`}
          >
            <div className="relative h-full flex flex-col justify-end p-24">
               <div className="w-24 h-24 bg-pink-500 rounded-3xl flex items-center justify-center text-white mb-12 shadow-3xl shadow-pink-500/30">
                 <Store className="w-12 h-12" />
               </div>
               <h3 className="text-6xl font-black tracking-tighter mb-6">Business.</h3>
               <p className="text-white/30 text-2xl font-bold mb-16 max-w-sm">Die All-in-One Management Suite für deinen Salon-Erfolg.</p>
               <div className="flex items-center gap-6 text-[11px] font-black text-slate-900 uppercase tracking-[0.5em] bg-white w-full py-8 rounded-[2rem] justify-center shadow-2xl group-hover:bg-indigo-100 transition-all">
                 Business Login <ArrowRight className="w-6 h-6" />
               </div>
            </div>
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className={`py-60 border-t ${isDark ? 'bg-slate-950 border-white/5' : 'bg-white border-indigo-50'}`}>
        <div className="max-w-[1800px] mx-auto px-20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-40">
            <div className="text-center md:text-left">
               <Logo />
               <p className={`mt-12 font-medium max-w-sm leading-relaxed text-xl ${isDark ? 'text-white/20' : 'text-slate-900/20'}`}>
                 ZenBook Beauty ist Teil des globalen Netzwerks für Ästhetik und Wohlbefinden. <br />
                 Berlin • London • Paris
               </p>
            </div>
          </div>
          <div className={`mt-60 pt-20 border-t flex flex-col md:flex-row items-center justify-between gap-10 ${isDark ? 'border-white/5' : 'border-indigo-50'}`}>
             <div className={`text-[10px] font-black uppercase tracking-[0.8em] ${isDark ? 'text-white/10' : 'text-slate-900/10'}`}>
                ZENBOOK BEAUTY © 2026 • EUROPEAN DIVISION
             </div>
             <div className="flex gap-16">
                {['Datenschutz', 'Impressum', 'AGB'].map(item => (
                  <button key={item} className={`text-[10px] font-black uppercase tracking-[0.4em] transition-all ${isDark ? 'text-white/20 hover:text-white' : 'text-slate-400 hover:text-indigo-600'}`}>{item}</button>
                ))}
             </div>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default Login;
