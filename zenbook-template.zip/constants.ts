
import { Service, Staff, Appointment, AppointmentStatus, Salon } from './types';

export const SERVICES: Service[] = [
  { id: '1', name: 'Balayage & Glossing', duration: 150, price: 125, category: 'Friseur' },
  { id: '2', name: 'Damenhaarschnitt & Styling', duration: 60, price: 65, category: 'Friseur' },
  { id: '3', name: 'Shellac Maniküre', duration: 45, price: 40, category: 'Nägel' },
  { id: '4', name: 'Gelnägel Neuset', duration: 90, price: 75, category: 'Nägel' },
  { id: '5', name: 'Ganzkörpermassage', duration: 60, price: 85, category: 'Massage' },
  { id: '6', name: 'Aquafacial Deep Clean', duration: 75, price: 110, category: 'Gesichtsbehandlung' },
  { id: '7', name: 'Diodenlaser Beine', duration: 40, price: 95, category: 'Haarentfernung' },
];

export const SALONS: Salon[] = [
  { id: 'sl1', name: 'The Art of Hair', category: 'Friseur', location: 'Berlin Mitte', rating: 4.9, reviews: 2450, image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&q=80&w=1200', priceLevel: '$$$' },
  { id: 'sl2', name: 'Glossy Nail Bar', category: 'Nägel', location: 'München Altstadt', rating: 4.8, reviews: 1120, image: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&q=80&w=1200', priceLevel: '$$' },
  { id: 'sl3', name: 'Pure Balance Spa', category: 'Wellness', location: 'Hamburg Eppendorf', rating: 4.7, reviews: 890, image: 'https://images.unsplash.com/photo-1544161515-4ae6ce6ea858?auto=format&fit=crop&q=80&w=1200', priceLevel: '$$$' },
  { id: 'sl4', name: 'Smooth Skin Studio', category: 'Haarentfernung', location: 'Köln Belgisches Viertel', rating: 4.6, reviews: 540, image: 'https://images.unsplash.com/photo-1559599101-f09722fb4948?auto=format&fit=crop&q=80&w=1200', priceLevel: '$$' },
  { id: 'sl5', name: 'Royal Facial Lab', category: 'Gesichtsbehandlung', location: 'Frankfurt Westend', rating: 5.0, reviews: 320, image: 'https://images.unsplash.com/photo-1570172619380-4101bdcc4e29?auto=format&fit=crop&q=80&w=1200', priceLevel: '$$$' },
];

export const STAFF: Staff[] = [
  { id: 's1', name: 'Christy', role: 'Master Stylist', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200', color: 'bg-orange-400 border-orange-500 text-white' },
  { id: 's2', name: 'Negav', role: 'Color Expert', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200', color: 'bg-teal-400 border-teal-500 text-white' },
  { id: 's3', name: 'Thi', role: 'Nail Artist', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200', color: 'bg-cyan-400 border-cyan-500 text-white' },
  { id: 's4', name: 'Steven', role: 'Spa Therapist', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200', color: 'bg-slate-800 border-slate-900 text-white' },
];

const today = new Date();
today.setHours(13, 30, 0, 0);

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'a1',
    startTime: new Date(today.getTime()),
    serviceId: '1',
    staffId: 's1',
    customerName: 'Sarah Müller',
    status: AppointmentStatus.CONFIRMED
  }
];

export const BUSINESS_HOURS = {
  start: 8,
  end: 20
};
