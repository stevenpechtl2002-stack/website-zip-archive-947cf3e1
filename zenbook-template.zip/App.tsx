
import React, { useState, useEffect } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronDown,
  Plus,
  Search as SearchIcon,
  Settings as SettingsIcon,
  Sparkles,
  LogOut,
  X,
  UserPlus,
  Users,
  Tag,
  Package,
  Layout,
  Bell,
  ArrowRight,
  Sun,
  Moon,
  ChevronLeft,
  Menu
} from 'lucide-react';
import { ViewType, Appointment, AppointmentStatus, Staff, UserRole, CalendarConfig } from './types';
import CalendarView from './components/CalendarView';
import ServiceManagement from './components/ServiceManagement';
import StaffManagement from './components/StaffManagement';
import Insights from './components/Insights';
import Settings from './components/Settings';
import Login from './components/Login';
import CustomerPortal from './components/CustomerPortal';
import SalonRegistration from './components/SalonRegistration';
import CustomerManagement from './components/CustomerManagement';
import ProductManagement from './components/ProductManagement';
import { storageService } from './services/storageService';

const navItems = [
  { id: 'insights', label: 'Übersicht', icon: <Layout className="w-5 h-5" />, color: 'text-indigo-500' },
  { id: 'calendar', label: 'Kalender', icon: <CalendarIcon className="w-5 h-5" />, color: 'text-blue-500' },
  { id: 'services', label: 'Leistungen', icon: <Tag className="w-5 h-5" />, color: 'text-pink-500' },
  { id: 'staff', label: 'Team', icon: <Users className="w-5 h-5" />, color: 'text-amber-500' },
  { id: 'products', label: 'Shop', icon: <Package className="w-5 h-5" />, color: 'text-emerald-500' },
  { id: 'customers', label: 'Kunden', icon: <UserPlus className="w-5 h-5" />, color: 'text-purple-500' },
];

const App: React.FC = () => {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [currentView, setCurrentView] = useState<any>('calendar'); // Direkt zum Kalender beim Testen
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [staffMembers, setStaffMembers] = useState<Staff[]>([]);
  const [services, setServices] = useState<any[]>([]);
  // Optimierte Standardwerte für den Treatwell-Look
  const [calendarConfig, setCalendarConfig] = useState<CalendarConfig>({ startHour: 8, endHour: 20, rowHeight: 80, columnWidth: 120 });
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [modalType, setModalType] = useState<'appointment' | 'block' | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('zenbook_theme');
    return saved === 'dark';
  });

  useEffect(() => {
    storageService.init();
    setAppointments(storageService.getAppointments());
    setStaffMembers(storageService.getStaff());
    setServices(storageService.getServices());
    setCalendarConfig(storageService.getCalendarConfig());
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add('theme-dark');
      localStorage.setItem('zenbook_theme', 'dark');
    } else {
      document.body.classList.remove('theme-dark');
      localStorage.setItem('zenbook_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  const ThemeToggle = () => (
    <button 
      onClick={toggleTheme}
      className={`fixed bottom-8 right-8 z-[1000] w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-90 group border backdrop-blur-xl ${isDarkMode ? 'bg-white/10 text-white border-white/20 hover:bg-white/20' : 'bg-white/80 text-indigo-600 border-indigo-100 hover:bg-white'}`}
      title={isDarkMode ? "Zum hellen Modus wechseln" : "Zum dunklen Modus wechseln"}
    >
      {isDarkMode ? <Sun className="w-7 h-7 group-hover:rotate-45 transition-transform" /> : <Moon className="w-7 h-7 group-hover:-rotate-12 transition-transform" />}
    </button>
  );

  const updateCalendarConfig = (newConfig: CalendarConfig) => {
    setCalendarConfig(newConfig);
    storageService.saveCalendarConfig(newConfig);
  };

  if (!userRole) return (
    <>
      <Login onLogin={setUserRole} onStartRegistration={() => setUserRole('salon_registration')} />
      <ThemeToggle />
    </>
  );
  
  if (userRole === 'salon_registration') return (
    <>
      <SalonRegistration onComplete={() => {
        storageService.init();
        setStaffMembers(storageService.getStaff());
        setUserRole('salon');
      }} onCancel={() => setUserRole(null)} />
      <ThemeToggle />
    </>
  );

  if (userRole === 'customer') return (
    <>
      <CustomerPortal onLogout={() => setUserRole(null)} />
      <ThemeToggle />
    </>
  );

  return (
    <div className={`flex min-h-screen selection:bg-indigo-500 selection:text-white transition-all duration-500 ${isDarkMode ? 'bg-slate-950 text-white' : 'bg-[#f8fafc] text-slate-900'}`}>
      
      {/* Editorial Sidebar with Collapse Feature */}
      <aside className={`hidden lg:flex flex-col p-4 z-50 sticky top-0 h-screen shrink-0 transition-all duration-500 ease-in-out ${isSidebarCollapsed ? 'w-20' : 'w-72'}`}>
        <div className={`${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-indigo-50 shadow-xl'} backdrop-blur-3xl rounded-[2rem] h-full flex flex-col p-4 border overflow-hidden`}>
          
          {/* Logo & Toggle Header */}
          <div className={`flex items-center gap-3 mb-8 transition-all ${isSidebarCollapsed ? 'justify-center' : 'justify-between'}`}>
            <div className={`flex items-center gap-3 ${isSidebarCollapsed ? 'hidden' : 'flex'}`}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm shadow-xl ${isDarkMode ? 'bg-indigo-500 text-white' : 'bg-indigo-600 text-white shadow-indigo-200'}`}>
                Z
              </div>
              <h1 className={`text-base font-black tracking-tighter leading-none ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>ZenBook</h1>
            </div>
            <button 
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              className={`p-2 rounded-lg transition-all ${isDarkMode ? 'bg-white/5 text-white/40 hover:text-white' : 'bg-slate-50 text-slate-400 hover:text-indigo-600'}`}
            >
              {isSidebarCollapsed ? <Menu className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>

          <nav className="space-y-1.5 flex-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                title={isSidebarCollapsed ? item.label : undefined}
                className={`w-full flex items-center px-3 py-3 rounded-xl text-xs font-bold transition-all duration-300 group overflow-hidden ${
                  currentView === item.id 
                    ? (isDarkMode ? 'bg-white text-indigo-950 shadow-2xl' : 'bg-indigo-600 text-white shadow-lg scale-[1.02]') 
                    : (isDarkMode ? 'text-white/40 hover:text-white hover:bg-white/5' : 'text-slate-400 hover:text-indigo-600 hover:bg-indigo-50/50')
                } ${isSidebarCollapsed ? 'justify-center' : 'gap-3'}`}
              >
                <span className={currentView === item.id ? 'text-inherit' : item.color}>
                  {item.icon}
                </span>
                {!isSidebarCollapsed && <span className="whitespace-nowrap">{item.label}</span>}
              </button>
            ))}
          </nav>

          <div className="mt-auto space-y-3">
            <button 
              onClick={() => setModalType('appointment')}
              className={`w-full py-4 bg-gradient-to-r from-indigo-600 to-pink-500 text-white rounded-xl font-black text-[9px] uppercase tracking-[0.2em] hover:scale-105 transition-all shadow-xl shadow-indigo-500/20 active:scale-95 flex items-center justify-center gap-2 ${isSidebarCollapsed ? 'px-0' : 'px-3'}`}
            >
              <Plus className="w-4 h-4 stroke-[3px]" /> {!isSidebarCollapsed && "Buchung"}
            </button>
            
            <button 
              onClick={() => setUserRole(null)}
              className={`w-full flex items-center p-2 rounded-xl border transition-all group overflow-hidden ${isDarkMode ? 'bg-white/5 border-white/10 hover:bg-rose-500/20' : 'bg-slate-50 border-slate-100 hover:bg-rose-50'} ${isSidebarCollapsed ? 'justify-center' : 'justify-between'}`}
            >
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 shrink-0 rounded-lg overflow-hidden ${isDarkMode ? 'bg-white/10' : 'bg-white border border-slate-100 shadow-sm'}`}>
                  <img src="https://i.pravatar.cc/100?u=salon" alt="avatar" />
                </div>
                {!isSidebarCollapsed && (
                  <div className="text-left overflow-hidden">
                    <p className={`text-[10px] font-black leading-none mb-0.5 group-hover:text-rose-600 truncate ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Logout</p>
                    <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Business</p>
                  </div>
                )}
              </div>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Experience Area */}
      <main className="flex-1 flex flex-col min-h-screen min-w-0 transition-all duration-500">
        
        {/* Header - Kompakter im Kalendermodus */}
        <header className={`${currentView === 'calendar' ? 'h-16' : 'h-24'} flex items-center justify-between px-6 lg:px-10 z-40 backdrop-blur-xl sticky top-0 transition-all ${isDarkMode ? 'bg-slate-950/80' : 'bg-[#f8fafc]/80'}`}>
          <div className="overflow-hidden">
            <h1 className={`${currentView === 'calendar' ? 'text-xl' : 'text-3xl lg:text-4xl'} font-black tracking-tighter truncate ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
              {navItems.find(n => n.id === currentView)?.label || 'System'}
            </h1>
          </div>

          <div className="flex items-center gap-3 lg:gap-4">
            <button className={`relative p-3 rounded-xl transition-all shadow-sm ${isDarkMode ? 'bg-white/5 text-slate-400 hover:text-white' : 'bg-white text-slate-400 hover:text-indigo-600 border border-indigo-50 shadow-indigo-100/50'}`}>
              <Bell className="w-4 h-4" />
              <div className="absolute top-3 right-3 w-1.5 h-1.5 bg-pink-500 rounded-full border-2 border-white"></div>
            </button>
            
            <button 
              onClick={() => setCurrentView('settings')} 
              className={`p-3 rounded-xl transition-all shadow-sm ${currentView === 'settings' ? 'bg-indigo-600 text-white' : (isDarkMode ? 'bg-white/5 text-slate-400 hover:text-white' : 'bg-white text-slate-400 hover:text-indigo-600 border border-indigo-50')}`}
            >
              <SettingsIcon className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Dynamic Content - Kalender nutzt vollen Platz */}
        <div className={`flex-1 ${currentView === 'calendar' ? 'px-0 pb-0' : 'px-6 lg:px-12 pb-12'}`}>
          <div className="max-w-full mx-auto min-h-full">
            <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 h-full">
              {currentView === 'calendar' ? (
                <div className={`overflow-hidden h-[calc(100vh-64px)] spring-in ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
                  <CalendarView 
                    appointments={appointments} 
                    selectedDate={selectedDate}
                    setSelectedDate={setSelectedDate}
                    onUpdateAppointment={() => {}} 
                    onDeleteAppointment={() => {}}
                    staff={staffMembers}
                    onSlotClick={() => setModalType('appointment')}
                    config={calendarConfig}
                    onConfigUpdate={updateCalendarConfig}
                    isDarkMode={isDarkMode}
                  />
                </div>
              ) : (
                <div className="max-w-[1600px] mx-auto mt-6">
                  {currentView === 'insights' && <Insights appointments={appointments} services={services} staff={staffMembers} isDarkMode={isDarkMode} />}
                  {currentView === 'customers' && <CustomerManagement isDarkMode={isDarkMode} />}
                  {currentView === 'products' && <ProductManagement isDarkMode={isDarkMode} />}
                  {currentView === 'services' && <ServiceManagement services={services} isDarkMode={isDarkMode} />}
                  {currentView === 'staff' && <StaffManagement staff={staffMembers} onAddStaff={() => {}} isDarkMode={isDarkMode} />}
                  {currentView === 'settings' && <Settings onSimulateIncoming={() => {}} onConfigChange={setCalendarConfig} isDarkMode={isDarkMode} />}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <ThemeToggle />

      {/* Modal System */}
      {modalType && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-indigo-950/40 backdrop-blur-xl p-6 animate-in fade-in duration-500">
           <div className={`rounded-[2rem] w-full max-w-2xl p-10 shadow-2xl border spring-in relative overflow-hidden ${isDarkMode ? 'bg-slate-900 border-white/10' : 'bg-white border-indigo-50'}`}>
              <div className="flex justify-between items-start mb-8 relative z-10">
                 <div>
                    <h4 className={`text-3xl font-black tracking-tighter leading-none mb-2 ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Neuer Termin</h4>
                    <p className="text-sm font-bold text-indigo-400">Präzision in jedem Detail.</p>
                 </div>
                 <button onClick={() => setModalType(null)} className={`p-3 rounded-xl transition-all active:scale-90 ${isDarkMode ? 'bg-white/5 text-slate-400 hover:text-white' : 'bg-slate-50 text-slate-400 hover:text-indigo-600'}`}>
                    <X className="w-6 h-6" />
                 </button>
              </div>
              
              <div className="space-y-6 relative z-10">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">Kunde</label>
                    <div className="relative">
                      <UserPlus className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-300" />
                      <input type="text" className={`w-full pl-16 pr-8 py-4 rounded-2xl border-none outline-none font-bold text-lg focus:ring-4 focus:ring-indigo-500/10 transition-all ${isDarkMode ? 'bg-white/5 text-white' : 'bg-indigo-50/50 text-slate-900'}`} placeholder="Gast oder Name" />
                    </div>
                 </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">Leistung</label>
                       <div className="relative">
                         <Tag className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-pink-300 pointer-events-none" />
                         <select className={`w-full pl-14 pr-8 py-4 rounded-2xl border-none outline-none font-black text-sm appearance-none focus:ring-4 focus:ring-indigo-500/10 transition-all ${isDarkMode ? 'bg-white/5 text-white' : 'bg-pink-50/30 text-slate-900'}`}>
                            {services.map(s => <option key={s.id} value={s.id} className={isDarkMode ? "bg-slate-900" : ""}>{s.name}</option>)}
                         </select>
                         <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 pointer-events-none" />
                       </div>
                    </div>
                    <div className="space-y-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1">Spezialist</label>
                       <div className="relative">
                         <Users className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-300 pointer-events-none" />
                         <select className={`w-full pl-14 pr-8 py-4 rounded-2xl border-none outline-none font-black text-sm appearance-none focus:ring-4 focus:ring-indigo-500/10 transition-all ${isDarkMode ? 'bg-white/5 text-white' : 'bg-amber-50/30 text-slate-900'}`}>
                            {staffMembers.map(s => <option key={s.id} value={s.id} className={isDarkMode ? "bg-slate-900" : ""}>{s.name}</option>)}
                         </select>
                         <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 pointer-events-none" />
                       </div>
                    </div>
                 </div>

                 <div className="pt-6">
                   <button className="w-full py-6 bg-gradient-to-r from-indigo-600 to-pink-500 text-white rounded-2xl font-black text-xs uppercase tracking-[0.4em] shadow-xl active:scale-[0.98] transition-all hover:opacity-90 flex items-center justify-center gap-3">
                      Termin bestätigen <ArrowRight className="w-5 h-5" />
                   </button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default App;
