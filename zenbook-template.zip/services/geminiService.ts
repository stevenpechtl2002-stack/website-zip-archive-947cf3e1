
import { GoogleGenAI, Type } from "@google/genai";
import { Appointment, Service, Staff, AppointmentStatus } from "../types";
import { startOfDay, addDays, setHours, setMinutes } from 'date-fns';

export const testConnectivity = async () => {
  // Initialize Gemini API client using the environment variable API_KEY
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Antworte nur mit dem Wort 'OK', wenn du bereit bist.",
    });
    // Fix: Access response.text directly (property, not method)
    return response.text?.trim().toUpperCase() === 'OK';
  } catch (error) {
    console.error("Connectivity Test Failed:", error);
    throw error;
  }
};

export const parseSmartBooking = async (
  input: string,
  staff: Staff[],
  services: Service[]
) => {
  // Initialize Gemini API client
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const context = {
    today: new Date().toISOString(),
    availableStaff: staff.map(s => ({ id: s.id, name: s.name })),
    availableServices: services.map(s => ({ id: s.id, name: s.name, duration: s.duration }))
  };

  const prompt = `Du bist ein Buchungs-Assistent für einen Salon. Interpretiere die folgende Nutzeranfrage: "${input}"
  Kontext: Heute ist der ${new Date().toLocaleDateString('de-DE')}.
  Personal: ${JSON.stringify(context.availableStaff)}
  Services: ${JSON.stringify(context.availableServices)}

  Extrahiere: 
  1. Service ID (suche die passendste ID)
  2. Staff ID (suche die passendste ID, falls erwähnt)
  3. Datum und Uhrzeit (relativ zu heute)
  4. Kundenname (falls erwähnt, sonst "Gast")

  Antworte NUR im JSON Format.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            serviceId: { type: Type.STRING },
            staffId: { type: Type.STRING },
            startTime: { type: Type.STRING, description: "ISO Date String" },
            customerName: { type: Type.STRING },
            confidence: { type: Type.NUMBER, description: "0 to 1 score" }
          },
          required: ["serviceId", "staffId", "startTime", "customerName"]
        }
      }
    });

    // Fix: Safely handle response text property using fallback to avoid JSON.parse errors
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Smart Booking Error:", error);
    return null;
  }
};

export const getBusinessInsights = async (
  appointments: Appointment[],
  services: Service[],
  staff: Staff[]
) => {
  // Initialize Gemini API client
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const dataContext = {
    totalBookings: appointments.length,
    services: services.map(s => ({ name: s.name, price: s.price })),
    staffNames: staff.map(s => s.name),
    bookingDetails: appointments.map(a => ({
      customer: a.customerName,
      status: a.status,
      time: a.startTime.toISOString()
    }))
  };

  const prompt = `Analysiere das folgende Buchungsszenario für einen Wellness-Salon in Deutschland:
  ${JSON.stringify(dataContext)}
  
  Gib mir eine prägnante geschäftliche Zusammenfassung und 3 konkrete Tipps zur Umsatzsteigerung oder Prozessoptimierung. 
  Antworte in professionellem Deutsch im JSON-Format.`;

  try {
    const response = await ai.models.generateContent({
      // Fix: Use gemini-3-pro-preview for complex business reasoning and optimization tasks
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "A summary of the current business state" },
            tips: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "List of 3 optimization tips"
            },
            nextWeekOutlook: { type: Type.STRING, description: "Expectation for the upcoming week" }
          },
          required: ["summary", "tips", "nextWeekOutlook"]
        }
      }
    });

    // Fix: Safely handle response text property
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      summary: "Zusammenfassung aktuell nicht verfügbar.",
      tips: ["Bieten Sie Paketpreise an.", "Nutzen Sie Social Media für Marketing.", "Optimieren Sie Ihre Pausenzeiten."],
      nextWeekOutlook: "Stabile Buchungslage erwartet."
    };
  }
};
